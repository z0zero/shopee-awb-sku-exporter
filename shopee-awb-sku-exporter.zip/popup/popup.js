"use strict";
(() => {
  // src/core/aggregate.ts
  var AggregationOverflowError = class extends Error {
    constructor() {
      super("Quantity aggregate exceeds JavaScript safe integer range.");
      this.name = "AggregationOverflowError";
    }
  };
  function aggregateRows(rows) {
    const quantityBySku = /* @__PURE__ */ new Map();
    let totalQuantity = 0;
    for (const row of rows) {
      const nextSkuQuantity = (quantityBySku.get(row.sku) ?? 0) + row.quantity;
      if (!Number.isSafeInteger(nextSkuQuantity)) {
        throw new AggregationOverflowError();
      }
      const nextTotalQuantity = totalQuantity + row.quantity;
      if (!Number.isSafeInteger(nextTotalQuantity)) {
        throw new AggregationOverflowError();
      }
      quantityBySku.set(row.sku, nextSkuQuantity);
      totalQuantity = nextTotalQuantity;
    }
    return {
      rows: Array.from(quantityBySku, ([sku, quantity]) => ({ sku, quantity })),
      uniqueSkus: quantityBySku.size,
      totalQuantity
    };
  }

  // src/core/csv.ts
  var CSV_NEEDS_QUOTING = /[",\r\n]/u;
  function padDatePart(value) {
    return String(value).padStart(2, "0");
  }
  function escapeCsvCell(value) {
    if (!CSV_NEEDS_QUOTING.test(value)) {
      return value;
    }
    return `"${value.replaceAll('"', '""')}"`;
  }
  function serializeCsv(rows) {
    const csvRows = [
      ["SKU", "Jumlah"],
      ...rows.map((row) => [row.sku, String(row.quantity)])
    ].map((row) => row.map(escapeCsvCell).join(","));
    return new TextEncoder().encode(`\uFEFF${csvRows.join("\r\n")}\r
`);
  }
  function buildCsvFilename(now) {
    const year = now.getFullYear();
    const month = padDatePart(now.getMonth() + 1);
    const day = padDatePart(now.getDate());
    const hours = padDatePart(now.getHours());
    const minutes = padDatePart(now.getMinutes());
    const seconds = padDatePart(now.getSeconds());
    return `shopee-awb-sku-${year}${month}${day}-${hours}${minutes}${seconds}.csv`;
  }

  // src/browser/csv-download.ts
  async function downloadScanCsv(result, partialAcknowledged, ports) {
    if (result === null) {
      return "unavailable";
    }
    if (result.status === "partial" && result.rows.length === 0) {
      return "unavailable";
    }
    if (result.status === "partial" && !partialAcknowledged) {
      return "acknowledgement-required";
    }
    if (result.status !== "complete" && result.status !== "partial") {
      return "unavailable";
    }
    let objectUrl;
    try {
      const aggregated = aggregateRows(result.rows);
      const bytes = serializeCsv(aggregated.rows);
      const blobBuffer = new ArrayBuffer(bytes.byteLength);
      new Uint8Array(blobBuffer).set(bytes);
      const blob = new Blob([blobBuffer], { type: "text/csv;charset=utf-8" });
      objectUrl = ports.createObjectUrl(blob);
      await ports.download({
        url: objectUrl,
        filename: buildCsvFilename(ports.now()),
        saveAs: true
      });
      return "started";
    } catch {
      return "failed";
    } finally {
      if (objectUrl !== void 0) {
        ports.revokeObjectUrl(objectUrl);
      }
    }
  }

  // src/core/url.ts
  var SUPPORTED_ORIGIN = "https://seller.shopee.co.id";
  function isSupportedAwbUrl(value) {
    try {
      const url = new URL(value);
      const authority = value.match(/^[a-z][a-z\d+.-]*:\/\/([^/?#]*)/iu)?.[1];
      if (authority?.toLowerCase() !== "seller.shopee.co.id") {
        return false;
      }
      return url.protocol === "https:" && url.origin === SUPPORTED_ORIGIN && url.hostname === "seller.shopee.co.id" && url.port === "" && url.username === "" && url.password === "" && url.pathname === "/awbprint" && url.hash === "";
    } catch {
      return false;
    }
  }

  // src/shared/messages.ts
  var SCAN_STATUSES = [
    "complete",
    "partial",
    "empty",
    "inaccessible",
    "unsupported"
  ];
  var WARNING_CODES = [
    "MISSING_SKU",
    "AMBIGUOUS_SKU",
    "INVALID_QTY",
    "INACCESSIBLE_SOURCE",
    "UNSUPPORTED_LAYOUT",
    "PARTIAL_EXTRACTION"
  ];
  var WARNING_MESSAGES = {
    MISSING_SKU: "A product row is missing a SKU.",
    AMBIGUOUS_SKU: "SKU data is ambiguous and was not selected.",
    INVALID_QTY: "A quantity is invalid or exceeds the supported range.",
    INACCESSIBLE_SOURCE: "The source could not be read.",
    UNSUPPORTED_LAYOUT: "No supported product layout was recognized.",
    PARTIAL_EXTRACTION: "Some product rows could not be extracted."
  };
  function isRecord(value) {
    return typeof value === "object" && value !== null;
  }
  function isNonNegativeSafeInteger(value) {
    return typeof value === "number" && Number.isSafeInteger(value) && value >= 0;
  }
  function hasExactKeys(value, keys) {
    const expected = new Set(keys);
    return Object.keys(value).length === expected.size && Object.keys(value).every((key) => expected.has(key));
  }
  function isProductRow(value) {
    if (!isRecord(value)) {
      return false;
    }
    return hasExactKeys(value, ["sku", "quantity", "labelIndex", "source"]) && typeof value.sku === "string" && value.sku.length > 0 && isNonNegativeSafeInteger(value.quantity) && value.quantity > 0 && isNonNegativeSafeInteger(value.labelIndex) && value.labelIndex > 0 && (value.source === "dom" || value.source === "pdf");
  }
  function isWarning(value) {
    if (!isRecord(value)) {
      return false;
    }
    const hasLabelIndex = hasExactKeys(value, ["code", "message", "labelIndex"]);
    const hasNoLabelIndex = hasExactKeys(value, ["code", "message"]);
    if (!hasLabelIndex && !hasNoLabelIndex || !WARNING_CODES.includes(value.code) || typeof value.message !== "string" || value.message !== WARNING_MESSAGES[value.code]) {
      return false;
    }
    return !hasLabelIndex || isNonNegativeSafeInteger(value.labelIndex) && value.labelIndex > 0;
  }
  function isScanResult(value) {
    if (!isRecord(value)) {
      return false;
    }
    if (!(hasExactKeys(value, [
      "status",
      "labelsInspected",
      "rowsDetected",
      "uniqueSkus",
      "totalQuantity",
      "rows",
      "warnings"
    ]) && SCAN_STATUSES.includes(value.status) && isNonNegativeSafeInteger(value.labelsInspected) && isNonNegativeSafeInteger(value.rowsDetected) && isNonNegativeSafeInteger(value.uniqueSkus) && isNonNegativeSafeInteger(value.totalQuantity) && Array.isArray(value.rows) && Array.isArray(value.warnings))) {
      return false;
    }
    const rows = value.rows;
    if (!rows.every(isProductRow) || !value.warnings.every(isWarning)) {
      return false;
    }
    const uniqueSkus = new Set(rows.map((row) => row.sku));
    const totalQuantity = rows.reduce((total, row) => total + row.quantity, 0);
    const hasValidCounters = value.rowsDetected === rows.length && value.uniqueSkus === uniqueSkus.size && Number.isSafeInteger(totalQuantity) && value.totalQuantity === totalQuantity;
    if (!hasValidCounters) {
      return false;
    }
    if (value.status === "complete") {
      return rows.length > 0 && value.warnings.length === 0;
    }
    if (value.status === "partial") {
      return rows.length > 0 && value.warnings.some((warning) => warning.code === "PARTIAL_EXTRACTION");
    }
    return rows.length === 0 && value.rowsDetected === 0 && value.uniqueSkus === 0 && value.totalQuantity === 0;
  }
  function isScanResponse(value) {
    return isRecord(value) && hasExactKeys(value, ["type", "result"]) && value.type === "SCAN_RESULT" && isScanResult(value.result);
  }

  // src/ui/scan-result.ts
  var ELEMENT_IDS = {
    status: "status",
    summary: "summary-list",
    warnings: "warnings-list",
    acknowledgementLabel: "partial-acknowledgement-label",
    acknowledgement: "partial-acknowledgement",
    download: "download-button"
  };
  var scanResultElementIds = ELEMENT_IDS;
  function summaryLines(result) {
    return [
      `Labels inspected: ${result.labelsInspected}`,
      `Product rows: ${result.rowsDetected}`,
      `Unique SKUs: ${result.uniqueSkus}`,
      `Total quantity: ${result.totalQuantity}`
    ];
  }
  function warningLine(message, labelIndex) {
    return labelIndex === void 0 ? message : `${message} (Label ${labelIndex})`;
  }
  function readyStatusText(surface) {
    return surface === "awb" ? "Ready to scan." : "Choose a downloaded Shopee AWB PDF.";
  }
  function unsupportedStatusText(surface) {
    return surface === "awb" ? "Open an AWB route to scan." : "No supported product table was found in the downloaded Shopee AWB PDF.";
  }
  function deriveScanViewModel(result, partialAcknowledged, surface) {
    if (result === null) {
      return {
        statusText: readyStatusText(surface),
        summaryLines: [],
        warningLines: [],
        showAcknowledgement: false,
        canDownload: false,
        downloadLabel: "Download CSV"
      };
    }
    const warnings = result.warnings.map(
      (item) => warningLine(item.message, item.labelIndex)
    );
    switch (result.status) {
      case "complete":
        return {
          statusText: "Scan complete.",
          summaryLines: summaryLines(result),
          warningLines: warnings,
          showAcknowledgement: false,
          canDownload: true,
          downloadLabel: "Download CSV"
        };
      case "partial":
        return {
          statusText: "Review and acknowledge every warning before downloading.",
          summaryLines: summaryLines(result),
          warningLines: warnings,
          showAcknowledgement: true,
          canDownload: partialAcknowledged,
          downloadLabel: "Download partial result"
        };
      case "empty":
        return {
          statusText: "No product rows found. Verify the print document.",
          summaryLines: summaryLines(result),
          warningLines: warnings,
          showAcknowledgement: false,
          canDownload: false,
          downloadLabel: "Download CSV"
        };
      case "inaccessible":
        return {
          statusText: "Could not read the source. Wait and retry, or report viewer access.",
          summaryLines: summaryLines(result),
          warningLines: warnings,
          showAcknowledgement: false,
          canDownload: false,
          downloadLabel: "Download CSV"
        };
      case "unsupported":
        return {
          statusText: unsupportedStatusText(surface),
          summaryLines: summaryLines(result),
          warningLines: warnings,
          showAcknowledgement: false,
          canDownload: false,
          downloadLabel: "Download CSV"
        };
    }
  }
  function replaceListContents(list, lines) {
    while (list.firstChild !== null) {
      list.removeChild(list.firstChild);
    }
    for (const line of lines) {
      const item = list.ownerDocument.createElement("li");
      item.textContent = line;
      list.appendChild(item);
    }
  }
  function requiredElement(root, id) {
    const element2 = root.getElementById(id);
    if (!(element2 instanceof root.defaultView.HTMLElement)) {
      throw new Error("Popup shell is missing a required control.");
    }
    return element2;
  }
  function renderScanView(model, root) {
    const status = requiredElement(root, ELEMENT_IDS.status);
    const summary = requiredElement(root, ELEMENT_IDS.summary);
    const warnings = requiredElement(root, ELEMENT_IDS.warnings);
    const acknowledgementLabel = requiredElement(
      root,
      ELEMENT_IDS.acknowledgementLabel
    );
    const acknowledgement = requiredElement(
      root,
      ELEMENT_IDS.acknowledgement
    );
    const download = requiredElement(
      root,
      ELEMENT_IDS.download
    );
    status.textContent = model.statusText;
    replaceListContents(summary, model.summaryLines);
    replaceListContents(warnings, model.warningLines);
    acknowledgementLabel.hidden = !model.showAcknowledgement;
    acknowledgement.disabled = !model.showAcknowledgement;
    acknowledgement.checked = model.showAcknowledgement && model.canDownload;
    download.disabled = !model.canDownload;
    download.textContent = model.downloadLabel;
  }

  // src/popup/controller.ts
  function inaccessibleResult() {
    return {
      status: "inaccessible",
      labelsInspected: 0,
      rowsDetected: 0,
      uniqueSkus: 0,
      totalQuantity: 0,
      rows: [],
      warnings: [
        { code: "INACCESSIBLE_SOURCE", message: "The source could not be read." }
      ]
    };
  }
  function unsupportedResult() {
    return {
      status: "unsupported",
      labelsInspected: 0,
      rowsDetected: 0,
      uniqueSkus: 0,
      totalQuantity: 0,
      rows: [],
      warnings: []
    };
  }
  function element(root, id) {
    const value = root.getElementById(id);
    if (!(value instanceof root.defaultView.HTMLElement)) {
      throw new Error("Popup shell is missing a required control.");
    }
    return value;
  }
  function createPopupController(root, ports) {
    const scanButton = element(root, "scan-button");
    const choosePdfButton = element(
      root,
      "choose-pdf-button"
    );
    const acknowledgement = element(
      root,
      scanResultElementIds.acknowledgement
    );
    const downloadButton = element(
      root,
      scanResultElementIds.download
    );
    const status = element(root, scanResultElementIds.status);
    let result = null;
    let partialAcknowledged = false;
    let scanning = false;
    function render() {
      renderScanView(
        deriveScanViewModel(result, partialAcknowledged, "awb"),
        root
      );
    }
    function setStatusOverride(message) {
      status.textContent = message;
    }
    function setScanning(value) {
      scanning = value;
      scanButton.disabled = value;
      choosePdfButton.disabled = value;
      if (value) {
        acknowledgement.disabled = true;
        downloadButton.disabled = true;
      }
    }
    async function scan() {
      if (scanning) {
        return;
      }
      result = null;
      partialAcknowledged = false;
      render();
      setScanning(true);
      setStatusOverride("Scanning\u2026");
      try {
        const tab = await ports.getActiveTab();
        if (tab === null || !Number.isSafeInteger(tab.id) || tab.id < 0 || tab.url === void 0 || !isSupportedAwbUrl(tab.url)) {
          result = unsupportedResult();
          return;
        }
        const response = await ports.requestScan(tab.id);
        result = isScanResponse(response) ? response.result : inaccessibleResult();
      } catch {
        result = inaccessibleResult();
      } finally {
        setScanning(false);
        render();
      }
    }
    async function openLocalPdfPage() {
      if (scanning) {
        return;
      }
      try {
        await ports.openLocalPdfPage();
      } catch {
        setStatusOverride("Could not open the downloaded PDF page. Try again.");
      }
    }
    function acknowledgePartial(acknowledged) {
      if (scanning || result?.status !== "partial") {
        acknowledgement.checked = false;
        partialAcknowledged = false;
        render();
        return;
      }
      partialAcknowledged = acknowledged;
      acknowledgement.checked = acknowledged;
      render();
    }
    async function download() {
      const outcome = await downloadScanCsv(
        result,
        partialAcknowledged,
        ports
      );
      switch (outcome) {
        case "acknowledgement-required":
          setStatusOverride(
            "Review and acknowledge every warning before downloading."
          );
          break;
        case "unavailable":
          setStatusOverride("A downloadable scan result is not available.");
          break;
        case "failed":
          setStatusOverride("The CSV download failed. Try again.");
          break;
      }
    }
    render();
    return { scan, openLocalPdfPage, acknowledgePartial, download };
  }

  // src/popup/index.ts
  function createPopupPorts() {
    return {
      getActiveTab: async () => {
        const [tab] = await chrome.tabs.query({
          active: true,
          lastFocusedWindow: true
        });
        return tab === void 0 || tab.id === void 0 ? null : { id: tab.id, url: tab.url };
      },
      requestScan: (tabId) => chrome.tabs.sendMessage(tabId, {
        type: "SCAN_REQUEST"
      }),
      openLocalPdfPage: async () => {
        await chrome.tabs.create({
          url: chrome.runtime.getURL("local-pdf/local-pdf.html")
        });
      },
      download: (options) => chrome.downloads.download(options),
      createObjectUrl: (blob) => URL.createObjectURL(blob),
      revokeObjectUrl: (url) => URL.revokeObjectURL(url),
      now: () => /* @__PURE__ */ new Date()
    };
  }
  function main() {
    const controller = createPopupController(document, createPopupPorts());
    document.getElementById("scan-button")?.addEventListener("click", () => void controller.scan());
    document.getElementById("choose-pdf-button")?.addEventListener("click", () => void controller.openLocalPdfPage());
    document.getElementById(scanResultElementIds.acknowledgement)?.addEventListener("change", (event) => {
      const input = event.currentTarget;
      if (input instanceof HTMLInputElement) {
        controller.acknowledgePartial(input.checked);
      }
    });
    document.getElementById(scanResultElementIds.download)?.addEventListener("click", () => void controller.download());
  }
  if (typeof document !== "undefined" && typeof chrome !== "undefined") {
    main();
  }
})();
